import UIKit

class ViewController: UIViewController {
    private var number : Int = 0
    private var CountGuesses : Int = 0
    private var GuessAgain = false
    private var guessNumber : Int = 0
    
    
    
    @IBOutlet weak var UserGuessedNumberTextField: UITextField!

    @IBOutlet weak var resultLabel: UILabel!
    
    // it is used to remove time and battery from the view Controller
    override var prefersStatusBarHidden: Bool{
        return true
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        number = Int(arc4random_uniform(100))
       // print(number)
        
    }


    // action Button
    @IBAction func GuessButton(_ sender: Any) {
 
    // after clicking the button it will vanish the keypad
        
        UserGuessedNumberTextField.resignFirstResponder()
        
        
        if Int(UserGuessedNumberTextField.text!)! > number {
        resultLabel.text = "Guessed Number is Greater than Computer Chosen Number"
            CountGuesses+=1
        
    }
        else if Int(UserGuessedNumberTextField.text!)! < number{
            resultLabel.text = "Guessed Number is Lesser than Computer Chosen Number"
            GuessAgain = true
            
        }
        else if Int(UserGuessedNumberTextField.text!)! == number{
            resultLabel.text = "Congratulation!!! You Guessed it right. It Took You \(CountGuesses) Guesses to Guess the number. "
        }
    
        
       
    }
 
    
    // it will make the keyboard disappear when we click it in vc
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

}

